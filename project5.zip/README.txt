Dongyang Li
Wenting Li

Q1: For which communication(s) do you use the SSL encryption? If you are encrypting the communication from (1) to (2) in Figure 2, for example, write (1)→(2) in your answer.
A: We encrypted the communication from (4)-(5) and(5)-(6).


Q2: How do you ensure that the item was purchased exactly at the Buy_Price of that particular item?
A: The buy_price is stored into the session array whenever a user is visiting an item page, cuz “never trust user’s input”.
