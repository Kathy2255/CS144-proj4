With all requirements done!

Servlet/JSP done
Google Map done
Google Suggestion / Search Interface done